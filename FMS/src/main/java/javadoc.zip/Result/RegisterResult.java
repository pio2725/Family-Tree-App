package Result;

/** The body of the register response */
public class RegisterResult {

    /** The authToken of the user */
    private String authToken;

    /** The user name of the user */
    private String userName;

    /** The person ID of the user */
    private String personID;

    /** The error message */
    private String message;

    /** Creating a result body with authToken, username, person ID, and message if needed
     *  @param authToken the unique access token for the user
     *  @param userName the user name of the user
     *  @param personID the personID of the user
     *  @param message the error message for the result
     */
    public RegisterResult(String authToken, String userName, String personID, String message) {
        this.authToken = authToken;
        this.userName = userName;
        this.personID = personID;
        this.message = message;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
