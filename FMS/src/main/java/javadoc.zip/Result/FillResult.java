package Result;

/** The body of a fill result with a message */
public class FillResult {

    /** The message which is either success or error */
    private String message;

    /** Creating a fill result with proper message
     *  @param message the success message or an error
     */
    public FillResult(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
