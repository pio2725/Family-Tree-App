package Result;

/** The body of a load result with a message */
public class LoadResult {

    /** The message which is either success or error response */
    private String message;

    /** Creating a load result with a proper message
     *  @param message the message either success or error
     */
    public LoadResult(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
