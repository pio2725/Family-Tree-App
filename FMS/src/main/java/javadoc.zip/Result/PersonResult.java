package Result;

import Model.Person;

/** The response body of all family members */
public class PersonResult {

    /** The array of Person objects */
    private Person[] data;

    /** The message which is either success or an error */
    private String message;

    /** Creating family result with
     *  @param data the array of family members
     *  @param message the message of error if needed
     */
    public PersonResult(Person[] data, String message) {
        this.data = data;
        this.message = message;
    }

    public Person[] getData() {
        return data;
    }

    public void setData(Person[] data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
