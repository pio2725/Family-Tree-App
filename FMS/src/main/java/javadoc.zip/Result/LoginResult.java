package Result;

/** The body of a login result */
public class LoginResult {

    /** The authorization token of the user */
    private String authToken;

    /** The name of the user */
    private String userName;

    /** The person ID of the user */
    private String personID;

    /** The possible error message */
    private String message;

    /** Creating a login result with the token, username, personID, and a possible message
     *  @param authToken the unique access token of the user
     *  @param userName the username of the user
     *  @param personID the personID of the user
     *  @param message the possible error message
     */
    public LoginResult(String authToken, String userName, String personID, String message) {
        this.authToken = authToken;
        this.userName = userName;
        this.personID = personID;
        this.message = message;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
