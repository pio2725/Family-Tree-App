package Result;

import Model.Event;

/** The response body of all events */
public class EventResult {

    /** The array of Event objects */
    private Event[] data;

    /** The message to be displayed */
    private String message;

    /** Creating a event result
     *  @param  data the array of all events
     *  @param message  the message if it has an error
     */
    public EventResult(Event[] data, String message) {
        this.data = data;
        this.message = message;
    }

    public Event[] getData() {
        return data;
    }

    public void setData(Event[] data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
