package Result;

/** The body of a clear result */
public class ClearResult {

    /** The message either success or error */
    private String message;

    /** Creating a clear result body with a message
     *  @param message either success or error message
     */
    public ClearResult(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
