package Service;

import Result.ClearResult;

/** Clear all data from the database, including
 *  accounts, tokens, person, and event data */
public class ClearService {

    /** Creating a clear service */
    public ClearService() {

    }

    /** Delete all data from the database
     *  @return return a clear result body with the message */
    public ClearResult clear() {
        return null;
    }

}
