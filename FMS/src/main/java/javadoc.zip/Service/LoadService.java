package Service;

import Reqeust.LoadRequest;
import Result.LoadResult;


/** Clear all data and then load data into the database */
public class LoadService {


    /** Creating a load service */
    public LoadService() {

    }

    /** Clear all data from the database, and then loads the posted person,
     *  user, and event data into the database
     *  @param r the load request with the username and the specified number of generations
     *  @return return the load result with the message
     */
    public LoadResult load(LoadRequest r) {
        return null;
    }
}
