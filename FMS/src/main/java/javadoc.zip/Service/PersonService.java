package Service;

import Result.PersonResult;


/** Get all family members of the current user */
public class PersonService {


    /** Creating Person service */
    public PersonService() {

    }

    /** Get all family members that the current user has
     *  @param  authToken the auth token to discern the current user
     *  @return the user's family members as JSON
     */
    public PersonResult getFamilyMembers(String authToken) {
        return null;
    }
}
