package Service;

import Reqeust.RegisterRequest;
import Result.RegisterResult;

/** Register for a new user */
public class RegisterService {

    /** Creating a register service */
    public RegisterService() {

    }

    /** Creating a user, person, and 4 generations of ancestor data, log in and return token
     *  @param r register request object given
     *  @return return register result object with token, username, and personID
     */
    public RegisterResult register(RegisterRequest r) {
        return null;
    }
}
