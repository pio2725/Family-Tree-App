package Service;

import Result.EventResult;

/** Get all events for all family members of the current user */
public class EventService {

    /** Creating a event service */
    public EventService() {

    }

    /** Get all events for all family members of the current user
     *  @param authToken the unique token for the current user
     *  @return  returns the event result with a JSON objects
     */
    public EventResult getAllEvents(String authToken) {
        return null;
    }
}
