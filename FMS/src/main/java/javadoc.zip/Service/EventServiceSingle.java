package Service;

import Result.EventResultSingle;

/** Get a single event */
public class EventServiceSingle {

    /** Creating a single event service */
    public EventServiceSingle() {

    }

    /** Get a single event and its information
     *  @param eventID the unique eventID
     *  @return the single event result with the information
     */
    public EventResultSingle getSingleEvent(String eventID) {
        return null;
    }
}
