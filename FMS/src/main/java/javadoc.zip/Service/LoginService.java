package Service;

import Reqeust.LoginRequest;
import Result.LoginResult;

/** log in a user */
public class LoginService {


    /** Creating a login service */
    public LoginService() {

    }

    /** Logs in the user and returns a token
     *  @param r the login request with the username and the password
     *  @return the login result with an auth token
     */
    public LoginResult login(LoginRequest r) {
        return null;
    }
}
