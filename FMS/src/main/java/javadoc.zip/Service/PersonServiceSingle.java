package Service;

import Result.PersonResultSingle;

/** Get a single person's information */
public class PersonServiceSingle {


    /** Creating a single person service */
    public PersonServiceSingle() {

    }

    /** Get a single person's information by personID
     *  @param  personID the unique personID of the person
     *  @return the single person result with person's information
     */
    public PersonResultSingle getPerson(String personID) {
        return null;
    }
}
