package DAO;

import java.sql.Connection;

/** Database connection and dealing with the table */
public class Database {

    /** Connection for the driver */
    private Connection connection;

    /** Open a connection to make a change to the database
     *  @throws DataAccessException throws exception when it's unable to open connection to the database
     *  @return return the valid connection
     */
    public Connection openConnection() throws DataAccessException {
        return null;
    }

    /** End the transaction and either commit or rollback
     *  @param commit true if want to commit the changes to the database, or false if something went wrong
     *  @throws DataAccessException throws exception when it's unable to close database connection
     */
    public void closeConnection(boolean commit) throws DataAccessException {

    }

    /** Create tables to the database
     *  @throws DataAccessException throws exception when encountered with SQL error
     */
    public void createTables() throws DataAccessException {

    }

    /** Delete tables from the database
     *  @throws DataAccessException throws exception when SQL error occurred while clearing tables
     */
    public void clearTables() throws DataAccessException {

    }

}
