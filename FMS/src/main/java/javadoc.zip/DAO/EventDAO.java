package DAO;

import Model.Event;

import java.sql.Connection;
import java.util.List;

/** Accessing and interacting with Event data in the database */
public class EventDAO {

    /** Connection to the database */
    private Connection connection;

    /** Make connection with the given connection to the database
     *  @param connection connection given for the database connection */
    public EventDAO(Connection connection) {
        this.connection = connection;
    }

    /** Insert new Event into the database
     *  @param event the event that would be inserted to the database
     *  @throws DataAccessException throws exception if unable to open connection
     *  @return true if insertion was made correctly
     */
    public boolean insertEvent(Event event) throws DataAccessException {
        return false;
    }

    /** Find the event with the eventID from the database and return
     *  @param eventID the unique eventID to find Event in the database
     *  @throws  DataAccessException throws exception if an error occured finding event
     *  @return return the event if it was found, null if not
     */
    public Event findEvent(String eventID) throws DataAccessException {
        return null;
    }

    /** Find all events with the unique token and return all events
     *  @param authToken the unique token of the user
     *  @return  return list of all the events for all family members of the user*/
    public List<Event> getAllFamilyEvents(String authToken) {
        return null;
    }

    /** Delete everything in the table
     *  @throws DataAccessException throws an exception when an error occurs
     */
    public void clearTable() throws DataAccessException {

    }

    /** Delete everything in the table associated with a certain username
     *  @param userName the username to delete data
     *  @throws DataAccessException throws an exception if an error occurs
     */
    public void deleteData(String userName) throws DataAccessException {

    }

}
