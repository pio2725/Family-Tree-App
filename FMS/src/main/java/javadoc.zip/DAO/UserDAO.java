package DAO;

import Model.User;

import java.sql.Connection;

/** Interacting between the database and User data */
public class UserDAO {

    /** Connection to the database */
    private Connection connection;

    /** Make connection with the given connection to the database
     *  @param connection connection given for the database connection
     */
    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    /** Insert new User into the database
     *  @param user new user that would be inserted to the database
     *  @throws DataAccessException throws exception if an error occurs
     *  @return return true if nothing went wrong and want to commit
     */
    public boolean insertUser(User user) throws DataAccessException {
        return false;
    }

    /** Find the user by unique username and return User if exists
     *  @param userName the unique user name to find User in the table
     *  @throws  DataAccessException throws an exception if an error occurs
     *  @return return User if found, or null
     */
    public User findUserByName (String userName) throws DataAccessException {
        return null;
    }

    /** Find the user by unique accessToken and return User if exists
     *  @param accessToken the unique token for the user
     *  @throws DataAccessException throws an exception if an error occurs
     *  @return return User if found, or null
     */
    public User findUserByToken (String accessToken) throws DataAccessException {
        return null;
    }

    /** Delete everything in the table
     *  @throws DataAccessException throws an exception when an error occurs
     */
    public void clearTable() throws DataAccessException {

    }

    /** Delete everything in the table associated with a certain username
     *  @param userName the username to delete data
     *  @throws DataAccessException throws an exception if an error occurs
     */
    public void deleteData(String userName) throws DataAccessException {

    }
}
