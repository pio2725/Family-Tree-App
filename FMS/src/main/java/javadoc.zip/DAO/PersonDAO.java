package DAO;

import Model.Person;

import java.sql.Connection;
import java.util.List;

/** Interacting between the database and Person data */
public class PersonDAO {

    /** Connection to the database */
    private Connection connection;

    /** Make connection with the given connection to the database
     *  @param connection connection given for the database connection */
    public PersonDAO(Connection connection) {
        this.connection = connection;
    }

    /** Insert person into the database
     *  @param person the person given to insert to the database
     *  @throws DataAccessException throws an exception if an error occurs
     *  @return return true if inserted correctly
     */
    public boolean insertPerson(Person person) throws DataAccessException {
        return false;
    }

    /** Find person with the given person ID and return Person
     *  @param personID the unique person ID
     *  @throws DataAccessException throws an exception if an error occurs
     *  @return return Person if found in the database, or null if not
     */
    public Person findPerson(String personID) throws DataAccessException {
        return null;
    }

    /** Find the user with the auth token and return the list of all family members
     *  @param accessToken the unique token to find the user
     *  @throws DataAccessException throws an exception if an error occurs
     *  @return return the list of Person that the user has
     */
    public List<Person> getAllFamilyMembers(String accessToken) throws DataAccessException {
        return null;
    }

    /** Delete everything in the table
     *  @throws DataAccessException throws an exception when an error occurs
     */
    public void clearTable() throws DataAccessException {

    }

    /** Delete everything in the table associated with a certain username
     *  @param userName the username to delete data
     *  @throws DataAccessException throws an exception if an error occurs
     */
    public void deleteData(String userName) throws DataAccessException {

    }
}
