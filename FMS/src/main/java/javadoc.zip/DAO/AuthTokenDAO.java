package DAO;

import Model.AuthToken;

import java.sql.Connection;

/** Interacting between the database and Authorization token data */
public class AuthTokenDAO {

    /** Connection to the database */
    private Connection connection;

    /** Make connection with the given connection to the database
     *  @param connection connection given for the database connection */
    public AuthTokenDAO(Connection connection) {
        this.connection = connection;
    }

    /** Insert created AuthToken into the database
     *  @param token the unique token for the user
     *  @throws DataAccessException throws an exception if an error occurs
     *  @return return true if it was inserted correctly
     */
    public boolean insertAuthToken(AuthToken token) throws DataAccessException {
        return false;
    }

    /** Find authorization token in the database
     *  @param accessToken the unique token used to find in the database
     *  @throws  DataAccessException throws an exception if an error occurs
     *  @return return AuthToken if found, or null if not
     */
    public AuthToken findAuthToken(String accessToken) throws DataAccessException {
        return null;
    }

    /** Delete everything in the table
     *  @throws DataAccessException throws an exception when an error occurs
     */
    public void clearTable() throws DataAccessException {

    }

    /** Delete everything in the table associated with a certain username
     *  @param userName the username to delete data
     *  @throws DataAccessException throws an exception if an error occurs
     */
    public void deleteData(String userName) throws DataAccessException {

    }

}
